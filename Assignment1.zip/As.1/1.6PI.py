def multiply(num1, exp1, exp2):
    eval("num1 * exp1)")
num1 = 4
exp1 = 1 - 1/3 + 1/5 - 1/7 + 1/9 - 1/11
exp2 = 1 - 1/3 + 1/5 - 1/7 + 1/9 - 1/11 +1/13 - 1/15
eval("num1 * exp1")

eval("num1 * exp2")
