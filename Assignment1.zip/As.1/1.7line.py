import turtle

point1 = (-39, 48)
point2 = (50, -50)

turtle.penup()
turtle.goto(point1)
turtle.pendown()
turtle.goto(point2)

turtle.hideturtle()
turtle.exitonclick()
