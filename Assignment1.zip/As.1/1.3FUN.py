Python 3.7.3 (v3.7.3:ef4ec6ed12, Mar 25 2019, 22:22:05) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
=============== RESTART: C:\Users\zehailem\Desktop\As.1\FUN.py ===============
FFFFFFF U     U NN    N
FF      U     U NNN   N
FFFFFFF U     U NN N  N
FF       U   U  NN  N N
FF        UUU   NN   NN
>>> 
