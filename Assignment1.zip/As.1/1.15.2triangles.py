from turtle import *

canvas = Screen()
canvas.setup(400,400)

right(60)
forward(100)
right(120)
forward(100)
right(120)
forward(200)
left(120)
forward(100)
left(120)
forward(100)

