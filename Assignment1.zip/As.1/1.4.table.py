from tabulate import tabulate

mydata = [("a", "a^2", "a^3"),
          ("1", "1", "1"),
          ("2", "4", "8")
          ("3", "9", "27"),
          ("4", "16", "64")]
print(tabulate(mydata))
