from turtle import *
canvas = Screen()
canvas.setup(300,300)


forward(200)
left(180)
forward(100)
right(90)
forward(100)
right(180)
forward(200)

