from turtle import *

canvas = Screen()
canvas.setup(300,300)

right(60)
forward(100)
right(120)
forward(100)
right(120)
forward(100)


