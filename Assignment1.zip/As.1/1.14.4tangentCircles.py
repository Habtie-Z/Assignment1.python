import turtle
from turtle import *
canvas = Screen()
canvas.setup(400,400)
t = turtle.Turtle()

t.pensize(3)

def drawCircle(color, x, y):
    t.color(color)
    t.pensize()
    t.goto(x,y)
    t.down()
    t.circle(50)

t.penup()
drawCircle("green", 0, 0)
t.penup()
drawCircle("brown", 103, 0)
t.penup()
drawCircle("red", 0, -103)
t.penup()
drawCircle("blue", 103, -103)
