#Program to draw stars in Python Turtle
import turtle
from turtle import *
canvas = Screen()
canvas.setup(400,400)
t = turtle.Turtle()
 

t.right(72)
t.forward(150)
t.right(144)
t.forward(150)
t.right(144)
t.forward(150)
t.right(144)
t.forward(150)
t.right(144)
t.forward(150)
