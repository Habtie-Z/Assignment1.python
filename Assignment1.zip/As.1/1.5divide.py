def divide(exp1, exp2):
    eval("exp1 / exp2)")
exp1 = 9.5 * 4.5 - (2.5*3)
exp2 = 45.5 - 3.5
eval("exp1 / exp2")
    
