from turtle import *

canvas = Screen()
canvas.setup(300,300)

goto(0, 0)
goto(40, -69.28)
goto(-40, -69.28)
goto(-80, -9.8)
goto(-40, 69)
goto(40, 69)
goto(80, 0)

