import turtle
from turtle import *

pensize(2)

for i in range(6):
    forward(100)
    left(60)
    
