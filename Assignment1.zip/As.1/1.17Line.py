import turtle
from turtle import *

canvas = Screen()
canvas.setup(300,300)

goto(-39, 48)
goto(50, -50)

